
# BLOCKCHAIN PROJECT 2 #
## Bruce Darcy ##

I am leaving the node modules out of the tarball for space purposes, run npm install before using my project.


With my implementation for list players in the contract, I opted to use an array to store all the names rather than a form of linked list. Because we dont care about the order of the names, we don't have to do any iteration to do any operation on the array. There is also a name to index mapping that goes along with the array so we don't have to iterate to find a name inside of it. To delete an element, we simple swap it with the end element then delete it off of the end.

The strings are concatenated by the view function and returned to the user seperated by newline characters. Because the listPlayers is a view function, I don't need to consider gas cost.

The screenshot in this directory has both the mocha tests and the GUI in the same image.
