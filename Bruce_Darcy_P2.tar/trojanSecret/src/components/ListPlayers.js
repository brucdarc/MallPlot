import React, { Component } from "react";
import { Button, Header, Icon, Modal, Form, Message } from "semantic-ui-react";
import web3 from "../web3";
import trojanSecret from "../trojanSecret";

export default class ListPlayers extends Component {
  state = {
    modalOpen: false,
    players: "",
    message: "",
    errorMessage: ""
  };
  
  handleOpen = async () => {
    this.setState({ modalOpen: true });
      let players = await trojanSecret.methods.listPlayers().call();
      players = players.split("\n").join(", ")
      this.setState({ players });
  }

  handleClose = () => this.setState({ modalOpen: false });

  render() {
    return (
      <Modal
        trigger={
          <Button color="purple" onClick={this.handleOpen}>
            List all Players
          </Button>
        }
        open={this.state.modalOpen}
        onClose={this.handleClose}
      >
        <Header icon="browser" content="List All Players" />
        <Modal.Content>
          <h3>
            Players Registered to play the game:
            <br />
            <br />
            {this.state.players}

          </h3>
        </Modal.Content>
        <Modal.Actions>
          <Button color="red" onClick={this.handleClose} inverted>
            <Icon name="cancel" /> Close
          </Button>
        </Modal.Actions>
      </Modal>
    );
  }
}
